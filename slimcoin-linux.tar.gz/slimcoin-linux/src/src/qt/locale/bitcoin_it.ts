<?xml version="1.0" ?><!DOCTYPE TS><TS language="it" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="14"/>
        <source>About SLIMCoin</source>
        <translation>Info su SLIMCoin</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="53"/>
        <source>&lt;b&gt;SLIMCoin&lt;/b&gt; version</source>
        <translation>Versione di &lt;b&gt;SLIMCoin&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="85"/>
        <source>Copyright © 2011-2013 SLIMCoin Developers

This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file license.txt or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation>Copyright © 2011-2013 SLIMCoin Developers

Questo è un software sperimentale.

Distribuito sotto la licenza software MIT/X11, vedi il file license.txt incluso oppure su http://www.opensource.org/licenses/mit-license.php.

Questo prodotto include software sviluppato dal progetto OpenSSL per l&apos;uso del Toolkit OpenSSL (http://www.openssl.org/), software crittografico scritto da Eric Young (eay@cryptsoft.com) e software UPnP scritto da Thomas Bernard.</translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <location filename="../forms/addressbookpage.ui" line="14"/>
        <source>Address Book</source>
        <translation>Rubrica</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="20"/>
        <source>These are your SLIMCoin addresses for receiving payments.  You may want to give a different one to each sender so you can keep track of who is paying you.</source>
        <translation>Questi sono i tuoi indirizzi SLIMCoin per ricevere pagamenti. Potrai darne uno diverso ad ognuno per tenere così traccia di chi ti sta pagando.</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="33"/>
        <source>Double-click to edit address or label</source>
        <translation>Fai doppio click per modificare o cancellare l&apos;etichetta</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="57"/>
        <source>Create a new address</source>
        <translation>Crea un nuovo indirizzo</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="60"/>
        <source>&amp;New Address...</source>
        <translation>&amp;Nuovo indirizzo...</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="71"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copia l&apos;indirizzo attualmente selezionato nella clipboard</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="74"/>
        <source>&amp;Copy to Clipboard</source>
        <translation>&amp;Copia nella clipboard</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="85"/>
        <source>Show &amp;QR Code</source>
        <translation>Mostra il codice &amp;QR</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="96"/>
        <source>Sign a message to prove you own this address</source>
        <translation>Firma un messaggio per dimostrare di possedere questo indirizzo</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="99"/>
        <source>&amp;Sign Message</source>
        <translation>&amp;Firma il messaggio</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="110"/>
        <source>Delete the currently selected address from the list. Only sending addresses can be deleted.</source>
        <translation>Cancella l&apos;indirizzo attualmente selezionato dalla lista. Solo indirizzi d&apos;invio possono essere cancellati.</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="113"/>
        <source>&amp;Delete</source>
        <translation>&amp;Cancella</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="61"/>
        <source>Copy address</source>
        <translation>Copia l&apos;indirizzo</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="62"/>
        <source>Copy label</source>
        <translation>Copia l&apos;etichetta</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="63"/>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="64"/>
        <source>Delete</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="281"/>
        <source>Export Address Book Data</source>
        <translation>Esporta gli indirizzi della rubrica</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="282"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Testo CSV (*.csv)</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="295"/>
        <source>Error exporting</source>
        <translation>Errore nell&apos;esportazione</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="295"/>
        <source>Could not write to file %1.</source>
        <translation>Impossibile scrivere sul file %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <location filename="../addresstablemodel.cpp" line="77"/>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <location filename="../addresstablemodel.cpp" line="77"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../addresstablemodel.cpp" line="113"/>
        <source>(no label)</source>
        <translation>(nessuna etichetta)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="26"/>
        <source>Dialog</source>
        <translation>Dialogo</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="32"/>
        <location filename="../forms/askpassphrasedialog.ui" line="97"/>
        <source>TextLabel</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="50"/>
        <source>Enter passphrase</source>
        <translation>Inserisci la passphrase</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="64"/>
        <source>New passphrase</source>
        <translation>Nuova passphrase</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="78"/>
        <source>Repeat new passphrase</source>
        <translation>Ripeti la passphrase</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="34"/>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Inserisci la passphrase per il portamonete.&lt;br/&gt;Per piacere usare unapassphrase di &lt;b&gt;10 o più caratteri casuali&lt;/b&gt;, o &lt;b&gt;otto o più parole&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="35"/>
        <source>Encrypt wallet</source>
        <translation>Cifra il portamonete</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="38"/>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Quest&apos;operazione necessita della passphrase per sbloccare il portamonete.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="43"/>
        <source>Unlock wallet</source>
        <translation>Sblocca il portamonete</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="46"/>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Quest&apos;operazione necessita della passphrase per decifrare il portamonete,</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="51"/>
        <source>Decrypt wallet</source>
        <translation>Decifra il portamonete</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="54"/>
        <source>Change passphrase</source>
        <translation>Cambia la passphrase</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="55"/>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Inserisci la vecchia e la nuova passphrase per il portamonete.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="101"/>
        <source>Confirm wallet encryption</source>
        <translation>Conferma la cifratura del portamonete</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="102"/>
        <source>WARNING: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR SLIMCoinS&lt;/b&gt;!
Are you sure you wish to encrypt your wallet?</source>
        <translation>ATTENZIONE: se si cifra il portamonete e si perde la frase d&apos;ordine, &lt;b&gt;SI PERDERANNO TUTTI I PROPRI SLIMCoin&lt;/b&gt;!
Si è sicuri di voler cifrare il portamonete?</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="111"/>
        <location filename="../askpassphrasedialog.cpp" line="160"/>
        <source>Wallet encrypted</source>
        <translation>Portamonete cifrato</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="112"/>
        <source>SLIMCoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your SLIMCoins from being stolen by malware infecting your computer.</source>
        <translation>SLIMCoin verrà ora chiuso per finire il processo di crittazione. Ricorda che criptare il tuo portamonete non può fornire una protezione totale contro furti causati da malware che dovessero infettare il tuo computer.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="208"/>
        <location filename="../askpassphrasedialog.cpp" line="232"/>
        <source>Warning: The Caps Lock key is on.</source>
        <translation>Attenzione: tasto Blocco maiuscole attivo.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="117"/>
        <location filename="../askpassphrasedialog.cpp" line="124"/>
        <location filename="../askpassphrasedialog.cpp" line="166"/>
        <location filename="../askpassphrasedialog.cpp" line="172"/>
        <source>Wallet encryption failed</source>
        <translation>Cifratura del portamonete fallita</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="118"/>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Cifratura del portamonete fallita a causa di un errore interno. Il portamonete non è stato cifrato.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="125"/>
        <location filename="../askpassphrasedialog.cpp" line="173"/>
        <source>The supplied passphrases do not match.</source>
        <translation>Le passphrase inserite non corrispondono.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="136"/>
        <source>Wallet unlock failed</source>
        <translation>Sblocco del portamonete fallito</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="137"/>
        <location filename="../askpassphrasedialog.cpp" line="148"/>
        <location filename="../askpassphrasedialog.cpp" line="167"/>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>La passphrase inserita per la decifrazione del portamonete è errata.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="147"/>
        <source>Wallet decryption failed</source>
        <translation>Decifrazione del portamonete fallita</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="161"/>
        <source>Wallet passphrase was succesfully changed.</source>
        <translation>Passphrase del portamonete modificata con successo.</translation>
    </message>
</context>
<context>
    <name>SLIMCoinGUI</name>
    <message>
        <location filename="../bitcoingui.cpp" line="69"/>
        <source>SLIMCoin Wallet</source>
        <translation>Portamonete di SLIMCoin</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="142"/>
        <location filename="../bitcoingui.cpp" line="464"/>
        <source>Synchronizing with network...</source>
        <translation>Sto sincronizzando con la rete...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="145"/>
        <source>Block chain synchronization in progress</source>
        <translation>sincronizzazione della catena di blocchi in corso</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="176"/>
        <source>&amp;Overview</source>
        <translation>&amp;Sintesi</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="177"/>
        <source>Show general overview of wallet</source>
        <translation>Mostra lo stato generale del portamonete</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="182"/>
        <source>&amp;Transactions</source>
        <translation>&amp;Transazioni</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="183"/>
        <source>Browse transaction history</source>
        <translation>Cerca nelle transazioni</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="188"/>
        <source>&amp;Address Book</source>
        <translation>&amp;Rubrica</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="189"/>
        <source>Edit the list of stored addresses and labels</source>
        <translation>Modifica la lista degli indirizzi salvati e delle etichette</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="194"/>
        <source>&amp;Receive coins</source>
        <translation>&amp;Ricevi monete</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="195"/>
        <source>Show the list of addresses for receiving payments</source>
        <translation>Mostra la lista di indirizzi su cui ricevere pagamenti</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="200"/>
        <source>&amp;Send coins</source>
        <translation>&amp;Invia monete</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="201"/>
        <source>Send coins to a SLIMCoin address</source>
        <translation>Invia monete ad un indirizzo SLIMCoin</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="206"/>
        <source>Sign &amp;message</source>
        <translation>Firma il &amp;messaggio</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="207"/>
        <source>Prove you control an address</source>
        <translation>Dimostra di controllare un indirizzo</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="226"/>
        <source>E&amp;xit</source>
        <translation>&amp;Esci</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="227"/>
        <source>Quit application</source>
        <translation>Chiudi applicazione</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="230"/>
        <source>&amp;About %1</source>
        <translation>&amp;Informazioni su %1</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="231"/>
        <source>Show information about SLIMCoin</source>
        <translation>Mostra informazioni su SLIMCoin</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="233"/>
        <source>About &amp;Qt</source>
        <translation>Informazioni su &amp;Qt</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="234"/>
        <source>Show information about Qt</source>
        <translation>Mostra informazioni su Qt</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="236"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opzioni...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="237"/>
        <source>Modify configuration options for SLIMCoin</source>
        <translation>Modifica configurazione opzioni per SLIMCoin</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="239"/>
        <source>Open &amp;SLIMCoin</source>
        <translation>Apri &amp;SLIMCoin</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="240"/>
        <source>Show the SLIMCoin window</source>
        <translation>Mostra la finestra SLIMCoin</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="241"/>
        <source>&amp;Export...</source>
        <translation>&amp;Esporta...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="242"/>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="243"/>
        <source>&amp;Encrypt Wallet</source>
        <translation>&amp;Cifra il portamonete</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="244"/>
        <source>Encrypt or decrypt wallet</source>
        <translation>Cifra o decifra il portamonete</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="246"/>
        <source>&amp;Backup Wallet</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="247"/>
        <source>Backup wallet to another location</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="248"/>
        <source>&amp;Change Passphrase</source>
        <translation>&amp;Cambia la passphrase</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="249"/>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Cambia la passphrase per la cifratura del portamonete</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="272"/>
        <source>&amp;File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="281"/>
        <source>&amp;Settings</source>
        <translation>&amp;Impostazioni</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="287"/>
        <source>&amp;Help</source>
        <translation>&amp;Aiuto</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="294"/>
        <source>Tabs toolbar</source>
        <translation>Barra degli strumenti &quot;Tabs&quot;</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="305"/>
        <source>Actions toolbar</source>
        <translation>Barra degli strumenti &quot;Azioni&quot;</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="317"/>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="407"/>
        <source>SLIMCoin-qt</source>
        <translation>SLIMCoin-qt</translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="449"/>
        <source>%n active connection(s) to SLIMCoin network</source>
        <translation><numerusform>%n connessione attiva alla rete SLIMCoin</numerusform><numerusform>%n connessioni attive alla rete SLIMCoin</numerusform></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="475"/>
        <source>Downloaded %1 of %2 blocks of transaction history.</source>
        <translation>Scaricati %1 dei %2 blocchi dello storico transazioni.</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="487"/>
        <source>Downloaded %1 blocks of transaction history.</source>
        <translation>Scaricati %1 blocchi dello storico transazioni.</translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="502"/>
        <source>%n second(s) ago</source>
        <translation><numerusform>%n secondo fa</numerusform><numerusform>%n secondi fa</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="506"/>
        <source>%n minute(s) ago</source>
        <translation><numerusform>%n minuto fa</numerusform><numerusform>%n minuti fa</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="510"/>
        <source>%n hour(s) ago</source>
        <translation><numerusform>%n ora fa</numerusform><numerusform>%n ore fa</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="514"/>
        <source>%n day(s) ago</source>
        <translation><numerusform>%n giorno fa</numerusform><numerusform>%n giorni fa</numerusform></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="520"/>
        <source>Up to date</source>
        <translation>Aggiornato</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="525"/>
        <source>Catching up...</source>
        <translation>In aggiornamento...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="533"/>
        <source>Last received block was generated %1.</source>
        <translation>L&apos;ultimo blocco ricevuto è stato generato %1</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="597"/>
        <source>This transaction is over the size limit.  You can still send it for a fee of %1, which goes to the nodes that process your transaction and helps to support the network.  Do you want to pay the fee?</source>
        <translation>Questa transazione è superiore al limite di dimensione. È comunque possibile inviarla con una commissione di %1, che va ai nodi che processano la tua transazione e contribuisce a sostenere la rete. Vuoi pagare la commissione?</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="602"/>
        <source>Sending...</source>
        <translation>Invio...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="629"/>
        <source>Sent transaction</source>
        <translation>Transazione inviata</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="630"/>
        <source>Incoming transaction</source>
        <translation>Transazione ricevuta</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="631"/>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Data: %1
Quantità: %2
Tipo: %3
Indirizzo: %4

</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="751"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Il portamonete è &lt;b&gt;cifrato&lt;/b&gt; e attualmente &lt;b&gt;sbloccato&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="759"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Il portamonete è &lt;b&gt;cifrato&lt;/b&gt; e attualmente &lt;b&gt;bloccato&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="782"/>
        <source>Backup Wallet</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="782"/>
        <source>Wallet Data (*.dat)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="785"/>
        <source>Backup Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="785"/>
        <source>There was an error trying to save the wallet data to the new location.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DisplayOptionsPage</name>
    <message>
        <location filename="../optionsdialog.cpp" line="270"/>
        <source>&amp;Unit to show amounts in: </source>
        <translation>&amp;Unità di misura degli importi in: </translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="274"/>
        <source>Choose the default subdivision unit to show in the interface, and when sending coins</source>
        <translation>Scegli l&apos;unità di suddivisione di default per l&apos;interfaccia e per l&apos;invio di monete</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="281"/>
        <source>Display addresses in transaction list</source>
        <translation>Mostra gli indirizzi nella lista delle transazioni</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="14"/>
        <source>Edit Address</source>
        <translation>Modifica l&apos;indirizzo</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="25"/>
        <source>&amp;Label</source>
        <translation>&amp;Etichetta</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="35"/>
        <source>The label associated with this address book entry</source>
        <translation>L&apos;etichetta associata a questo indirizzo nella rubrica</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="42"/>
        <source>&amp;Address</source>
        <translation>&amp;Indirizzo</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="52"/>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>L&apos;indirizzo associato a questa voce della rubrica. Si può modificare solo negli indirizzi di spedizione.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="20"/>
        <source>New receiving address</source>
        <translation>Nuovo indirizzo di ricezione</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="24"/>
        <source>New sending address</source>
        <translation>Nuovo indirizzo d&apos;invio</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="27"/>
        <source>Edit receiving address</source>
        <translation>Modifica indirizzo di ricezione</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="31"/>
        <source>Edit sending address</source>
        <translation>Modifica indirizzo d&apos;invio</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="91"/>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>L&apos;indirizzo inserito &quot;%1&quot; è già in rubrica.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="96"/>
        <source>The entered address &quot;%1&quot; is not a valid SLIMCoin address.</source>
        <translation>L&apos;indirizzo inserito &quot;%1&quot; non è un indirizzo SLIMCoin valido.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="101"/>
        <source>Could not unlock wallet.</source>
        <translation>Impossibile sbloccare il portamonete.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="106"/>
        <source>New key generation failed.</source>
        <translation>Generazione della nuova chiave non riuscita.</translation>
    </message>
</context>
<context>
    <name>MainOptionsPage</name>
    <message>
        <location filename="../optionsdialog.cpp" line="170"/>
        <source>&amp;Start SLIMCoin on window system startup</source>
        <translation>&amp;Fai partire SLIMCoin all&apos;avvio del sistema</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="171"/>
        <source>Automatically start SLIMCoin after the computer is turned on</source>
        <translation>Avvia automaticamente SLIMCoin all&apos;accensione del computer</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="175"/>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimizza sul tray invece che sulla barra delle applicazioni</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="176"/>
        <source>Show only a tray icon after minimizing the window</source>
        <translation>Mostra solo un&apos;icona nel tray quando si minimizza la finestra</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="180"/>
        <source>Map port using &amp;UPnP</source>
        <translation>Mappa le porte tramite l&apos;&amp;UPnP</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="181"/>
        <source>Automatically open the SLIMCoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Apri automaticamente la porta del client SLIMCoin sul router. Questo funziona solo se il router supporta UPnP ed è abilitato.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="185"/>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimizza alla chiusura</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="186"/>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Riduci ad icona, invece di uscire dall&apos;applicazione quando la finestra viene chiusa. Quando questa opzione è attivata, l&apos;applicazione verrà chiusa solo dopo aver selezionato Esci nel menu.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="190"/>
        <source>&amp;Connect through SOCKS4 proxy:</source>
        <translation>&amp;Collegati tramite SOCKS4 proxy:</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="191"/>
        <source>Connect to the Bitcon network through a SOCKS4 proxy (e.g. when connecting through Tor)</source>
        <translation>Connettiti alla rete Bitcon attraverso un proxy SOCKS4 (ad esempio quando ci si collega via Tor)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="196"/>
        <source>Proxy &amp;IP: </source>
        <translation>&amp;IP del proxy: </translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="202"/>
        <source>IP address of the proxy (e.g. 127.0.0.1)</source>
        <translation>Indirizzo IP del proxy (ad esempio 127.0.0.1)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="205"/>
        <source>&amp;Port: </source>
        <translation>&amp;Porta: </translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="211"/>
        <source>Port of the proxy (e.g. 1234)</source>
        <translation>Porta del proxy (es. 1234)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="217"/>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly.  Most transactions are 1 kB.  Fee 0.01 recommended.</source>
        <translation>Commissione di transazione per kB; è opzionale e contribuisce ad assicurare che le transazioni siano elaborate velocemente. Le transazioni sono per la maggior parte da 1 kB. Commissione raccomandata 0,01.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="223"/>
        <source>Pay transaction &amp;fee</source>
        <translation>Paga la &amp;commissione</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="226"/>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly. Most transactions are 1 kB. Fee 0.01 recommended.</source>
        <translation>Commissione di transazione per kB; è opzionale e contribuisce ad assicurare che le transazioni siano elaborate velocemente. Le transazioni sono per la maggior parte da 1 kB. Commissione raccomandata 0,01.</translation>
    </message>
</context>
<context>
    <name>MessagePage</name>
    <message>
        <location filename="../forms/messagepage.ui" line="14"/>
        <source>Message</source>
        <translation>Messaggio</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="20"/>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="38"/>
        <source>The address to send the payment to  (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>L&apos;indirizzo del beneficiario cui inviare il pagamento (ad esempio 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="48"/>
        <source>Choose adress from address book</source>
        <translation>Scegli l&apos;indirizzo dalla rubrica</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="58"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="71"/>
        <source>Paste address from clipboard</source>
        <translation>Incollare l&apos;indirizzo dagli appunti</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="81"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="93"/>
        <source>Enter the message you want to sign here</source>
        <translation>Inserisci qui il messaggio che vuoi firmare</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="105"/>
        <source>Click &quot;Sign Message&quot; to get signature</source>
        <translation>Clicca &quot;Firma il messaggio&quot; per ottenere la firma</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="117"/>
        <source>Sign a message to prove you own this address</source>
        <translation>Firma un messaggio per dimostrare di possedere questo indirizzo</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="120"/>
        <source>&amp;Sign Message</source>
        <translation>&amp;Firma il messaggio</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="131"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copia l&apos;indirizzo attualmente selezionato nella clipboard</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="134"/>
        <source>&amp;Copy to Clipboard</source>
        <translation>&amp;Copia nella clipboard</translation>
    </message>
    <message>
        <location filename="../messagepage.cpp" line="74"/>
        <location filename="../messagepage.cpp" line="89"/>
        <location filename="../messagepage.cpp" line="101"/>
        <source>Error signing</source>
        <translation>Errore nel firmare</translation>
    </message>
    <message>
        <location filename="../messagepage.cpp" line="74"/>
        <source>%1 is not a valid address.</source>
        <translation>%1 non è un indirizzo valido.</translation>
    </message>
    <message>
        <location filename="../messagepage.cpp" line="89"/>
        <source>Private key for %1 is not available.</source>
        <translation>La chiave privata per %1 non è disponibile.</translation>
    </message>
    <message>
        <location filename="../messagepage.cpp" line="101"/>
        <source>Sign failed</source>
        <translation>Firma non riuscita</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../optionsdialog.cpp" line="79"/>
        <source>Main</source>
        <translation>Principale</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="84"/>
        <source>Display</source>
        <translation>Mostra</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="104"/>
        <source>Options</source>
        <translation>Opzioni</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <location filename="../forms/overviewpage.ui" line="14"/>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="40"/>
        <source>Balance:</source>
        <translation>Saldo</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="47"/>
        <source>123.456 BTC</source>
        <translation>123,456 BTC</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="54"/>
        <source>Number of transactions:</source>
        <translation>Numero di transazioni:</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="61"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="68"/>
        <source>Unconfirmed:</source>
        <translation>Non confermato:</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="75"/>
        <source>0 BTC</source>
        <translation>0 BTC</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="82"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Wallet&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;⏎
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;⏎
p, li { white-space: pre-wrap; }⏎
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;⏎
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Wallet&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="122"/>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Transazioni recenti&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="103"/>
        <source>Your current balance</source>
        <translation>Saldo attuale</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="108"/>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Totale delle transazioni in corso di conferma, che non sono ancora incluse nel saldo attuale</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="111"/>
        <source>Total number of transactions in wallet</source>
        <translation>Numero delle transazioni effettuate</translation>
    </message>
</context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialogo</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="32"/>
        <source>QR Code</source>
        <translation>Codice QR</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="52"/>
        <source>Request Payment</source>
        <translation>Richiedi pagamento</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="67"/>
        <source>Amount:</source>
        <translation>Importo:</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="102"/>
        <source>BTC</source>
        <translation>BTC</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="118"/>
        <source>Label:</source>
        <translation>Etichetta:</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="141"/>
        <source>Message:</source>
        <translation>Messaggio:</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="183"/>
        <source>&amp;Save As...</source>
        <translation>&amp;Salva come...</translation>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="101"/>
        <source>Save Image...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="101"/>
        <source>PNG Images (*.png)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="14"/>
        <location filename="../sendcoinsdialog.cpp" line="122"/>
        <location filename="../sendcoinsdialog.cpp" line="127"/>
        <location filename="../sendcoinsdialog.cpp" line="132"/>
        <location filename="../sendcoinsdialog.cpp" line="137"/>
        <location filename="../sendcoinsdialog.cpp" line="143"/>
        <location filename="../sendcoinsdialog.cpp" line="148"/>
        <location filename="../sendcoinsdialog.cpp" line="153"/>
        <source>Send Coins</source>
        <translation>Spedisci SLIMCoin</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="64"/>
        <source>Send to multiple recipients at once</source>
        <translation>Spedisci a diversi beneficiari in una volta sola</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="67"/>
        <source>&amp;Add recipient...</source>
        <translation>&amp;Aggiungi beneficiario...</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="84"/>
        <source>Remove all transaction fields</source>
        <translation>Rimuovi tutti i campi della transazione</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="87"/>
        <source>Clear all</source>
        <translation>Cancella tutto</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="106"/>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="113"/>
        <source>123.456 BTC</source>
        <translation>123,456 BTC</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="144"/>
        <source>Confirm the send action</source>
        <translation>Conferma la spedizione</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="147"/>
        <source>&amp;Send</source>
        <translation>&amp;Spedisci</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="94"/>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="99"/>
        <source>Confirm send coins</source>
        <translation>Conferma la spedizione di SLIMCoin</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="100"/>
        <source>Are you sure you want to send %1?</source>
        <translation>Si è sicuri di voler spedire %1?</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="100"/>
        <source> and </source>
        <translation> e </translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="123"/>
        <source>The recepient address is not valid, please recheck.</source>
        <translation>L&apos;indirizzo del beneficiario non è valido, per cortesia controlla.</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="128"/>
        <source>The amount to pay must be larger than 0.</source>
        <translation>L&apos;importo da pagare dev&apos;essere maggiore di 0.</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="133"/>
        <source>Amount exceeds your balance</source>
        <translation>L&apos;importo è superiore al saldo attuale</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="138"/>
        <source>Total exceeds your balance when the %1 transaction fee is included</source>
        <translation>Il totale è superiore al saldo attuale includendo la commissione %1</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="144"/>
        <source>Duplicate address found, can only send to each address once in one send operation</source>
        <translation>Trovato un indirizzo doppio, si può spedire solo una volta a ciascun indirizzo in una singola operazione.</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="149"/>
        <source>Error: Transaction creation failed  </source>
        <translation>Errore: creazione della transazione fallita </translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="154"/>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Errore: la transazione è stata rifiutata. Ciò accade se alcuni SLIMCoin nel portamonete sono stati già spesi, ad esempio se è stata usata una copia del file wallet.dat e i SLIMCoin sono stati spesi dalla copia ma non segnati come spesi qui.</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="14"/>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="29"/>
        <source>A&amp;mount:</source>
        <translation>&amp;Importo:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="42"/>
        <source>Pay &amp;To:</source>
        <translation>Paga &amp;a:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="66"/>
        <location filename="../sendcoinsentry.cpp" line="26"/>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Inserisci un&apos;etichetta per questo indirizzo, per aggiungerlo nella rubrica</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="75"/>
        <source>&amp;Label:</source>
        <translation>&amp;Etichetta</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="93"/>
        <source>The address to send the payment to  (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>L&apos;indirizzo del beneficiario cui inviare il pagamento (ad esempio 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="103"/>
        <source>Choose address from address book</source>
        <translation>Scegli l&apos;indirizzo dalla rubrica</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="113"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="120"/>
        <source>Paste address from clipboard</source>
        <translation>Incollare l&apos;indirizzo dagli appunti</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="130"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="137"/>
        <source>Remove this recipient</source>
        <translation>Rimuovere questo beneficiario</translation>
    </message>
    <message>
        <location filename="../sendcoinsentry.cpp" line="25"/>
        <source>Enter a SLIMCoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Inserisci un indirizzo SLIMCoin (ad esempio 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <location filename="../transactiondesc.cpp" line="18"/>
        <source>Open for %1 blocks</source>
        <translation>Aperto per %1 blocchi</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="20"/>
        <source>Open until %1</source>
        <translation>Aperto fino a %1</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="26"/>
        <source>%1/offline?</source>
        <translation>%1/offline?</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="28"/>
        <source>%1/unconfirmed</source>
        <translation>%1/non confermato</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="30"/>
        <source>%1 confirmations</source>
        <translation>%1 conferme</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="47"/>
        <source>&lt;b&gt;Status:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Stato:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="52"/>
        <source>, has not been successfully broadcast yet</source>
        <translation>, non è stato ancora trasmesso con successo</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="54"/>
        <source>, broadcast through %1 node</source>
        <translation>, trasmesso attraverso %1 nodo</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="56"/>
        <source>, broadcast through %1 nodes</source>
        <translation>, trasmesso attraverso %1 nodi</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="60"/>
        <source>&lt;b&gt;Date:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Data:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="67"/>
        <source>&lt;b&gt;Source:&lt;/b&gt; Generated&lt;br&gt;</source>
        <translation>&lt;b&gt;Fonte:&lt;/b&gt; Generato&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="73"/>
        <location filename="../transactiondesc.cpp" line="90"/>
        <source>&lt;b&gt;From:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Da:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="90"/>
        <source>unknown</source>
        <translation>sconosciuto</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="91"/>
        <location filename="../transactiondesc.cpp" line="114"/>
        <location filename="../transactiondesc.cpp" line="173"/>
        <source>&lt;b&gt;To:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Per:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="94"/>
        <source> (yours, label: </source>
        <translation> (vostro, etichetta: </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="96"/>
        <source> (yours)</source>
        <translation> (vostro)</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="131"/>
        <location filename="../transactiondesc.cpp" line="145"/>
        <location filename="../transactiondesc.cpp" line="190"/>
        <location filename="../transactiondesc.cpp" line="207"/>
        <source>&lt;b&gt;Credit:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Credito:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="133"/>
        <source>(%1 matures in %2 more blocks)</source>
        <translation>(%1 matura in altri %2 blocchi)</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="137"/>
        <source>(not accepted)</source>
        <translation>(non accettate)</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="181"/>
        <location filename="../transactiondesc.cpp" line="189"/>
        <location filename="../transactiondesc.cpp" line="204"/>
        <source>&lt;b&gt;Debit:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Debito:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="195"/>
        <source>&lt;b&gt;Transaction fee:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Commissione:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="211"/>
        <source>&lt;b&gt;Net amount:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Importo netto:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="217"/>
        <source>Message:</source>
        <translation>Messaggio:</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="219"/>
        <source>Comment:</source>
        <translation>Commento:</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="221"/>
        <source>Transaction ID:</source>
        <translation>ID della transazione:</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="224"/>
        <source>Generated coins must wait 120 blocks before they can be spent.  When you generated this block, it was broadcast to the network to be added to the block chain.  If it fails to get into the chain, it will change to &quot;not accepted&quot; and not be spendable.  This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Bisogna attendere 120 blocchi prima di spendere I SLIMCoin generati. Quando è stato generato questo blocco, è stato trasmesso alla rete per aggiungerlo alla catena di blocchi. Se non riesce a entrare nella catena, verrà modificato in &quot;non accettato&quot; e non sarà spendibile. Questo può accadere a volte, se un altro nodo genera un blocco entro pochi secondi del tuo.</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="14"/>
        <source>Transaction details</source>
        <translation>Dettagli sulla transazione</translation>
    </message>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="20"/>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Questo pannello mostra una descrizione dettagliata della transazione</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Amount</source>
        <translation>Importo</translation>
    </message>
    <message numerus="yes">
        <location filename="../transactiontablemodel.cpp" line="274"/>
        <source>Open for %n block(s)</source>
        <translation><numerusform>Aperto per %n blocco</numerusform><numerusform>Aperto per %n blocchi</numerusform></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="277"/>
        <source>Open until %1</source>
        <translation>Aperto fino a %1</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="280"/>
        <source>Offline (%1 confirmations)</source>
        <translation>Offline (%1 conferme)</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="283"/>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Non confermati (%1 su %2 conferme)</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="286"/>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Confermato (%1 conferme)</translation>
    </message>
    <message numerus="yes">
        <location filename="../transactiontablemodel.cpp" line="295"/>
        <source>Mined balance will be available in %n more blocks</source>
        <translation><numerusform>Il saldo generato sarà disponibile tra %n altro blocco</numerusform><numerusform>Il saldo generato sarà disponibile tra %n altri blocchi</numerusform></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="301"/>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Questo blocco non è stato ricevuto da altri nodi e probabilmente non sarà accettato!</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="304"/>
        <source>Generated but not accepted</source>
        <translation>Generati, ma non accettati</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="347"/>
        <source>Received with</source>
        <translation>Ricevuto tramite</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="349"/>
        <source>Received from</source>
        <translation>Ricevuto da</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="352"/>
        <source>Sent to</source>
        <translation>Spedito a</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="354"/>
        <source>Payment to yourself</source>
        <translation>Pagamento a te stesso</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="356"/>
        <source>Mined</source>
        <translation>Ottenuto dal mining</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="394"/>
        <source>(n/a)</source>
        <translation>(N / a)</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="593"/>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Stato della transazione. Passare con il mouse su questo campo per vedere il numero di conferme.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="595"/>
        <source>Date and time that the transaction was received.</source>
        <translation>Data e ora in cui la transazione è stata ricevuta.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="597"/>
        <source>Type of transaction.</source>
        <translation>Tipo di transazione.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="599"/>
        <source>Destination address of transaction.</source>
        <translation>Indirizzo di destinazione della transazione.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="601"/>
        <source>Amount removed from or added to balance.</source>
        <translation>Importo rimosso o aggiunto al saldo.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <location filename="../transactionview.cpp" line="55"/>
        <location filename="../transactionview.cpp" line="71"/>
        <source>All</source>
        <translation>Tutti</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="56"/>
        <source>Today</source>
        <translation>Oggi</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="57"/>
        <source>This week</source>
        <translation>Questa settimana</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="58"/>
        <source>This month</source>
        <translation>Questo mese</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="59"/>
        <source>Last month</source>
        <translation>Il mese scorso</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="60"/>
        <source>This year</source>
        <translation>Quest&apos;anno</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="61"/>
        <source>Range...</source>
        <translation>Intervallo...</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="72"/>
        <source>Received with</source>
        <translation>Ricevuto tramite</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="74"/>
        <source>Sent to</source>
        <translation>Spedito a</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="76"/>
        <source>To yourself</source>
        <translation>A te</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="77"/>
        <source>Mined</source>
        <translation>Ottenuto dal mining</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="78"/>
        <source>Other</source>
        <translation>Altro</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="84"/>
        <source>Enter address or label to search</source>
        <translation>Inserisci un indirizzo o un&apos;etichetta da cercare</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="90"/>
        <source>Min amount</source>
        <translation>Importo minimo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="124"/>
        <source>Copy address</source>
        <translation>Copia l&apos;indirizzo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="125"/>
        <source>Copy label</source>
        <translation>Copia l&apos;etichetta</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="126"/>
        <source>Copy amount</source>
        <translation>Copia l&apos;importo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="127"/>
        <source>Edit label</source>
        <translation>Modifica l&apos;etichetta</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="128"/>
        <source>Show details...</source>
        <translation>Mostra i dettagli...</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="268"/>
        <source>Export Transaction Data</source>
        <translation>Esporta i dati della transazione</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="269"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Testo CSV (*.csv)</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="277"/>
        <source>Confirmed</source>
        <translation>Confermato</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="278"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="279"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="280"/>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="281"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="282"/>
        <source>Amount</source>
        <translation>Importo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="283"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="287"/>
        <source>Error exporting</source>
        <translation>Errore nell&apos;esportazione</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="287"/>
        <source>Could not write to file %1.</source>
        <translation>Impossibile scrivere sul file %1.</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="382"/>
        <source>Range:</source>
        <translation>Intervallo:</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="390"/>
        <source>to</source>
        <translation>a</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <location filename="../walletmodel.cpp" line="145"/>
        <source>Sending...</source>
        <translation>Invio...</translation>
    </message>
</context>
<context>
    <name>SLIMCoin-core</name>
    <message>
        <location filename="../bitcoinstrings.cpp" line="3"/>
        <source>SLIMCoin version</source>
        <translation>Versione di SLIMCoin</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="4"/>
        <source>Usage:</source>
        <translation>Utilizzo:</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="5"/>
        <source>Send command to -server or slimcoind</source>
        <translation>Manda il comando a -server o slimcoind
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="6"/>
        <source>List commands</source>
        <translation>Lista comandi
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="7"/>
        <source>Get help for a command</source>
        <translation>Aiuto su un comando
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="8"/>
        <source>Options:</source>
        <translation>Opzioni:
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="9"/>
        <source>Specify configuration file (default: SLIMCoin.conf)</source>
        <translation>Specifica il file di configurazione (di default: SLIMCoin.conf)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="10"/>
        <source>Specify pid file (default: slimcoind.pid)</source>
        <translation>Specifica il file pid (default: slimcoind.pid)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="11"/>
        <source>Generate coins</source>
        <translation>Genera SLIMCoin
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="12"/>
        <source>Don&apos;t generate coins</source>
        <translation>Non generare SLIMCoin
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="13"/>
        <source>Start minimized</source>
        <translation>Parti in icona
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="14"/>
        <source>Specify data directory</source>
        <translation>Specifica la cartella dati
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="15"/>
        <source>Specify connection timeout (in milliseconds)</source>
        <translation>Specifica il timeout di connessione (in millisecondi)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="16"/>
        <source>Connect through socks4 proxy</source>
        <translation>Connessione tramite socks4 proxy
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="17"/>
        <source>Allow DNS lookups for addnode and connect</source>
        <translation>Consenti ricerche DNS per aggiungere nodi e collegare
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="18"/>
        <source>Listen for connections on &lt;port&gt; (default: 8333 or testnet: 18333)</source>
        <translation>Ascolta le connessioni JSON-RPC su &lt;porta&gt; (default: 8333 o testnet: 18333)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="19"/>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>Mantieni al massimo &lt;n&gt; connessioni ai peer (default: 125)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="20"/>
        <source>Add a node to connect to</source>
        <translation>Aggiungi un nodo e connetti a
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="21"/>
        <source>Connect only to the specified node</source>
        <translation>Connetti solo al nodo specificato
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="22"/>
        <source>Don&apos;t accept connections from outside</source>
        <translation>Non accettare connessioni dall&apos;esterno
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="23"/>
        <source>Don&apos;t bootstrap list of peers using DNS</source>
        <translation>Non avviare la lista dei peer usando il DNS</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="24"/>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>Soglia di disconnessione dei peer di cattiva qualità (default: 100)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="25"/>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>Numero di secondi di sospensione che i peer di cattiva qualità devono trascorrere prima di riconnettersi (default: 86400)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="28"/>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 10000)</source>
        <translation>Buffer di ricezione massimo per connessione, &lt;n&gt;*1000 byte (default: 10000)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="29"/>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 10000)</source>
        <translation>Buffer di invio massimo per connessione, &lt;n&gt;*1000 byte (default: 10000)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="30"/>
        <source>Don&apos;t attempt to use UPnP to map the listening port</source>
        <translation>Non usare l&apos;UPnP per mappare la porta
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="31"/>
        <source>Attempt to use UPnP to map the listening port</source>
        <translation>Prova ad usare l&apos;UPnp per mappare la porta
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="32"/>
        <source>Fee per kB to add to transactions you send</source>
        <translation>Commissione per kB da aggiungere alle transazioni in uscita</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="33"/>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Accetta da linea di comando e da comandi JSON-RPC
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="34"/>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Esegui in background come demone e accetta i comandi
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="35"/>
        <source>Use the test network</source>
        <translation>Utilizza la rete di prova
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="36"/>
        <source>Output extra debugging information</source>
        <translation>Produci informazioni extra utili al debug</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="37"/>
        <source>Prepend debug output with timestamp</source>
        <translation>Anteponi all&apos;output di debug una marca temporale</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="38"/>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Invia le informazioni di trace/debug alla console invece che al file debug.log</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="39"/>
        <source>Send trace/debug info to debugger</source>
        <translation>Invia le informazioni di trace/debug al debugger</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="40"/>
        <source>Username for JSON-RPC connections</source>
        <translation>Nome utente per connessioni JSON-RPC
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="41"/>
        <source>Password for JSON-RPC connections</source>
        <translation>Password per connessioni JSON-RPC
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="42"/>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 8332)</source>
        <translation>Attendi le connessioni JSON-RPC su &lt;porta&gt; (default: 8332)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="43"/>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>Consenti connessioni JSON-RPC dall&apos;indirizzo IP specificato
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="44"/>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Inviare comandi al nodo in esecuzione su &lt;ip&gt; (default: 127.0.0.1)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="45"/>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Impostare la quantità di chiavi di riserva a &lt;n&gt; (default: 100)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="46"/>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Ripeti analisi della catena dei blocchi per cercare le transazioni  mancanti dal portamonete
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="47"/>
        <source>
SSL options: (see the SLIMCoin Wiki for SSL setup instructions)</source>
        <translation>
Opzioni SSL: (vedi il wiki di SLIMCoin per le istruzioni di configurazione SSL)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="50"/>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Utilizzare OpenSSL (https) per le connessioni  JSON-RPC
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="51"/>
        <source>Server certificate file (default: server.cert)</source>
        <translation>File certificato del server (default: server.cert)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="52"/>
        <source>Server private key (default: server.pem)</source>
        <translation>Chiave privata del server (default: server.pem)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="53"/>
        <source>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</source>
        <translation>Cifrari accettabili (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="56"/>
        <source>This help message</source>
        <translation>Questo messaggio di aiuto
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="57"/>
        <source>Cannot obtain a lock on data directory %s.  SLIMCoin is probably already running.</source>
        <translation>Non è possibile ottenere i dati sulla directory %s. Probabilmente SLIMCoin è già in esecuzione.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="60"/>
        <source>Loading addresses...</source>
        <translation>Caricamento indirizzi...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="61"/>
        <source>Error loading addr.dat</source>
        <translation>Errore caricamento addr.dat</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="63"/>
        <source>Error loading blkindex.dat</source>
        <translation>Errore caricamento blkindex.dat</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="65"/>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Errore caricamento wallet.dat: Wallet corrotto</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="66"/>
        <source>Error loading wallet.dat: Wallet requires newer version of SLIMCoin</source>
        <translation>Errore caricamento wallet.dat: il wallet richiede una versione nuova di SLIMCoin</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="67"/>
        <source>Wallet needed to be rewritten: restart SLIMCoin to complete</source>
        <translation>Il portamonete deve essere riscritto: riavviare SLIMCoin per completare</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="68"/>
        <source>Error loading wallet.dat</source>
        <translation>Errore caricamento wallet.dat</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="62"/>
        <source>Loading block index...</source>
        <translation>Caricamento dell&apos;indice del blocco...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="64"/>
        <source>Loading wallet...</source>
        <translation>Caricamento portamonete...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="69"/>
        <source>Rescanning...</source>
        <translation>Ripetere la scansione...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="70"/>
        <source>Done loading</source>
        <translation>Caricamento completato</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="71"/>
        <source>Invalid -proxy address</source>
        <translation>Indirizzo -proxy non valido</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="72"/>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;</source>
        <translation>Importo non valido per -paytxfee=&lt;amount&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="73"/>
        <source>Warning: -paytxfee is set very high.  This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Attenzione: -paytxfee è molto alta. Questa è la commissione che si paga quando si invia una transazione.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="76"/>
        <source>Error: CreateThread(StartNode) failed</source>
        <translation>Errore: CreateThread(StartNode) non riuscito</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="77"/>
        <source>Warning: Disk space is low  </source>
        <translation>Attenzione: lo spazio su disco è scarso </translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="78"/>
        <source>Unable to bind to port %d on this computer.  SLIMCoin is probably already running.</source>
        <translation>Impossibile collegarsi alla porta %d su questo computer. Probabilmente SLIMCoin è già in esecuzione.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="81"/>
        <source>Warning: Please check that your computer&apos;s date and time are correct.  If your clock is wrong SLIMCoin will not work properly.</source>
        <translation>Attenzione: si prega di controllare che la data del computer e l&apos;ora siano corrette. Se il vostro orologio è sbagliato SLIMCoin non funziona correttamente.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="84"/>
        <source>beta</source>
        <translation>beta</translation>
    </message>
</context>
</TS>