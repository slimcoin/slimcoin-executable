<?xml version="1.0" ?><!DOCTYPE TS><TS language="hr" version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="14"/>
        <source>About SLIMCoin</source>
        <translation>O SLIMCoinu</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="53"/>
        <source>&lt;b&gt;SLIMCoin&lt;/b&gt; version</source>
        <translation>&lt;b&gt;SLIMCoin&lt;/b&gt; verzija</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="85"/>
        <source>Copyright © 2011-2013 SLIMCoin Developers

This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file license.txt or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <location filename="../forms/addressbookpage.ui" line="14"/>
        <source>Address Book</source>
        <translation>Adresar</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="20"/>
        <source>These are your SLIMCoin addresses for receiving payments.  You may want to give a different one to each sender so you can keep track of who is paying you.</source>
        <translation>Ovo su vaše SLIMCoin adrese za primanje isplate. Možda želite dati drukčiju adresu svakom primatelju tako da možete pratiti tko je platio.</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="33"/>
        <source>Double-click to edit address or label</source>
        <translation>Dvostruki klik za uređivanje adrese ili oznake</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="57"/>
        <source>Create a new address</source>
        <translation>Dodajte novu adresu</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="60"/>
        <source>&amp;New Address...</source>
        <translation>&amp;Nova adresa...</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="71"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopiraj trenutno odabranu adresu u međuspremnik</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="74"/>
        <source>&amp;Copy to Clipboard</source>
        <translation>&amp;Kopiraj u međuspremnik</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="85"/>
        <source>Show &amp;QR Code</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="96"/>
        <source>Sign a message to prove you own this address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="99"/>
        <source>&amp;Sign Message</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="110"/>
        <source>Delete the currently selected address from the list. Only sending addresses can be deleted.</source>
        <translation>Brisanje trenutno odabrane adrese s popisa. Samo adrese za slanje se mogu izbrisati.</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="113"/>
        <source>&amp;Delete</source>
        <translation>&amp;Brisanje</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="61"/>
        <source>Copy address</source>
        <translation>Kopirati adresu</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="62"/>
        <source>Copy label</source>
        <translation>Kopirati oznaku</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="63"/>
        <source>Edit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="64"/>
        <source>Delete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="281"/>
        <source>Export Address Book Data</source>
        <translation>Izvoz podataka adresara</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="282"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Datoteka vrijednosti odvojenih zarezom (*. csv)</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="295"/>
        <source>Error exporting</source>
        <translation>Pogreška kod izvoza</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="295"/>
        <source>Could not write to file %1.</source>
        <translation>Ne mogu pisati u datoteku %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <location filename="../addresstablemodel.cpp" line="77"/>
        <source>Label</source>
        <translation>Oznaka</translation>
    </message>
    <message>
        <location filename="../addresstablemodel.cpp" line="77"/>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <location filename="../addresstablemodel.cpp" line="113"/>
        <source>(no label)</source>
        <translation>(bez oznake)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="26"/>
        <source>Dialog</source>
        <translation>Dijalog</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="32"/>
        <location filename="../forms/askpassphrasedialog.ui" line="97"/>
        <source>TextLabel</source>
        <translation>TekstualnaOznaka</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="50"/>
        <source>Enter passphrase</source>
        <translation>Unesite lozinku</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="64"/>
        <source>New passphrase</source>
        <translation>Nova lozinka</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="78"/>
        <source>Repeat new passphrase</source>
        <translation>Ponovite novu lozinku</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="34"/>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Unesite novi lozinku za novčanik. &lt;br/&gt; Molimo Vas da koristite zaporku od &lt;b&gt;10 ili više slučajnih znakova,&lt;/b&gt; ili &lt;b&gt;osam ili više riječi.&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="35"/>
        <source>Encrypt wallet</source>
        <translation>Šifriranje novčanika</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="38"/>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Ova operacija treba lozinku vašeg novčanika kako bi se novčanik otključao.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="43"/>
        <source>Unlock wallet</source>
        <translation>Otključaj novčanik</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="46"/>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Ova operacija treba lozinku vašeg novčanika kako bi se novčanik dešifrirao.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="51"/>
        <source>Decrypt wallet</source>
        <translation>Dešifriranje novčanika.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="54"/>
        <source>Change passphrase</source>
        <translation>Promjena lozinke</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="55"/>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Unesite staru i novu lozinku za novčanik.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="101"/>
        <source>Confirm wallet encryption</source>
        <translation>Potvrdi šifriranje novčanika</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="102"/>
        <source>WARNING: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR SLIMCoinS&lt;/b&gt;!
Are you sure you wish to encrypt your wallet?</source>
        <translation>UPOZORENJE: Ako šifrirate vaš novčanik i izgubite lozinku, &lt;b&gt;IZGUBIT ĆETE SVE SVOJE SLIMCoinSE!&lt;/b&gt;
Jeste li sigurni da želite šifrirati svoj novčanik?</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="111"/>
        <location filename="../askpassphrasedialog.cpp" line="160"/>
        <source>Wallet encrypted</source>
        <translation>Novčanik šifriran</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="112"/>
        <source>SLIMCoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your SLIMCoins from being stolen by malware infecting your computer.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="208"/>
        <location filename="../askpassphrasedialog.cpp" line="232"/>
        <source>Warning: The Caps Lock key is on.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="117"/>
        <location filename="../askpassphrasedialog.cpp" line="124"/>
        <location filename="../askpassphrasedialog.cpp" line="166"/>
        <location filename="../askpassphrasedialog.cpp" line="172"/>
        <source>Wallet encryption failed</source>
        <translation>Šifriranje novčanika nije uspjelo</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="118"/>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Šifriranje novčanika nije uspjelo zbog interne pogreške. Vaš novčanik nije šifriran.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="125"/>
        <location filename="../askpassphrasedialog.cpp" line="173"/>
        <source>The supplied passphrases do not match.</source>
        <translation>Priložene lozinke se ne podudaraju.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="136"/>
        <source>Wallet unlock failed</source>
        <translation>Otključavanje novčanika nije uspjelo</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="137"/>
        <location filename="../askpassphrasedialog.cpp" line="148"/>
        <location filename="../askpassphrasedialog.cpp" line="167"/>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Lozinka za dešifriranje novčanika nije točna.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="147"/>
        <source>Wallet decryption failed</source>
        <translation>Dešifriranje novčanika nije uspjelo</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="161"/>
        <source>Wallet passphrase was succesfully changed.</source>
        <translation>Lozinka novčanika je uspješno promijenjena.</translation>
    </message>
</context>
<context>
    <name>SLIMCoinGUI</name>
    <message>
        <location filename="../bitcoingui.cpp" line="69"/>
        <source>SLIMCoin Wallet</source>
        <translation>SLIMCoin novčanik</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="142"/>
        <location filename="../bitcoingui.cpp" line="464"/>
        <source>Synchronizing with network...</source>
        <translation>Usklađivanje s mrežom ...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="145"/>
        <source>Block chain synchronization in progress</source>
        <translation>Sinkronizacija lanca blokova u tijeku</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="176"/>
        <source>&amp;Overview</source>
        <translation>&amp;Pregled</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="177"/>
        <source>Show general overview of wallet</source>
        <translation>Prikaži opći pregled novčanika</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="182"/>
        <source>&amp;Transactions</source>
        <translation>&amp;Transakcije</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="183"/>
        <source>Browse transaction history</source>
        <translation>Pretraži povijest transakcija</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="188"/>
        <source>&amp;Address Book</source>
        <translation>&amp;Adresar</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="189"/>
        <source>Edit the list of stored addresses and labels</source>
        <translation>Uređivanje popisa pohranjenih adresa i oznaka</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="194"/>
        <source>&amp;Receive coins</source>
        <translation>&amp;Primanje novca</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="195"/>
        <source>Show the list of addresses for receiving payments</source>
        <translation>Prikaži popis adresa za primanje isplate</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="200"/>
        <source>&amp;Send coins</source>
        <translation>&amp;Pošalji novac</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="201"/>
        <source>Send coins to a SLIMCoin address</source>
        <translation>Slanje novca na SLIMCoin adresu</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="206"/>
        <source>Sign &amp;message</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="207"/>
        <source>Prove you control an address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="226"/>
        <source>E&amp;xit</source>
        <translation>&amp;Izlaz</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="227"/>
        <source>Quit application</source>
        <translation>Izlazak iz programa</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="230"/>
        <source>&amp;About %1</source>
        <translation>&amp;Više o %1</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="231"/>
        <source>Show information about SLIMCoin</source>
        <translation>Prikaži informacije o SLIMCoinu</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="233"/>
        <source>About &amp;Qt</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="234"/>
        <source>Show information about Qt</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="236"/>
        <source>&amp;Options...</source>
        <translation>&amp;Postavke</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="237"/>
        <source>Modify configuration options for SLIMCoin</source>
        <translation>Promijeni postavke konfiguracije za SLIMCoin</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="239"/>
        <source>Open &amp;SLIMCoin</source>
        <translation>Otvori &amp;SLIMCoin</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="240"/>
        <source>Show the SLIMCoin window</source>
        <translation>Prikaži SLIMCoin prozor</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="241"/>
        <source>&amp;Export...</source>
        <translation>&amp;Izvoz...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="242"/>
        <source>Export the data in the current tab to a file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="243"/>
        <source>&amp;Encrypt Wallet</source>
        <translation>&amp;Šifriraj novčanik</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="244"/>
        <source>Encrypt or decrypt wallet</source>
        <translation>Šifriranje ili dešifriranje novčanika</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="246"/>
        <source>&amp;Backup Wallet</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="247"/>
        <source>Backup wallet to another location</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="248"/>
        <source>&amp;Change Passphrase</source>
        <translation>&amp;Promijena lozinke</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="249"/>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Promijenite lozinku za šifriranje novčanika</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="272"/>
        <source>&amp;File</source>
        <translation>&amp;Datoteka</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="281"/>
        <source>&amp;Settings</source>
        <translation>&amp;Konfiguracija</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="287"/>
        <source>&amp;Help</source>
        <translation>&amp;Pomoć</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="294"/>
        <source>Tabs toolbar</source>
        <translation>Traka kartica</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="305"/>
        <source>Actions toolbar</source>
        <translation>Traka akcija</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="317"/>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="407"/>
        <source>SLIMCoin-qt</source>
        <translation>SLIMCoin-qt</translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="449"/>
        <source>%n active connection(s) to SLIMCoin network</source>
        <translation><numerusform>%n aktivna veza na SLIMCoin mrežu</numerusform><numerusform>%n aktivne veze na SLIMCoin mrežu</numerusform><numerusform>%n aktivnih veza na SLIMCoin mrežu</numerusform></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="475"/>
        <source>Downloaded %1 of %2 blocks of transaction history.</source>
        <translation>Preuzeto %1 od %2 blokova povijesti transakcije.</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="487"/>
        <source>Downloaded %1 blocks of transaction history.</source>
        <translation>Preuzeto %1 blokova povijesti transakcije.</translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="502"/>
        <source>%n second(s) ago</source>
        <translation><numerusform>prije %n sekunde</numerusform><numerusform>prije %n sekunde</numerusform><numerusform>prije %n sekundi</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="506"/>
        <source>%n minute(s) ago</source>
        <translation><numerusform>prije %n minute</numerusform><numerusform>prije %n minute</numerusform><numerusform>prije %n minuta</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="510"/>
        <source>%n hour(s) ago</source>
        <translation><numerusform>prije %n sata</numerusform><numerusform>prije %n sata</numerusform><numerusform>prije %n sati</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="514"/>
        <source>%n day(s) ago</source>
        <translation><numerusform>prije %n dana</numerusform><numerusform>prije %n dana</numerusform><numerusform>prije %n dana</numerusform></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="520"/>
        <source>Up to date</source>
        <translation>Ažurno</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="525"/>
        <source>Catching up...</source>
        <translation>Ažuriranje...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="533"/>
        <source>Last received block was generated %1.</source>
        <translation>Zadnji primljeni blok je generiran %1.</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="597"/>
        <source>This transaction is over the size limit.  You can still send it for a fee of %1, which goes to the nodes that process your transaction and helps to support the network.  Do you want to pay the fee?</source>
        <translation>Ova transakcija je preko ograničenja veličine. Možete ju ipak poslati za naknadu od %1, koja se daje čvorovima koji procesiraju vaše transakcije i tako podržavate mrežu. Želite li platiti naknadu?</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="602"/>
        <source>Sending...</source>
        <translation>Slanje...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="629"/>
        <source>Sent transaction</source>
        <translation>Poslana transakcija</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="630"/>
        <source>Incoming transaction</source>
        <translation>Dolazna transakcija</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="631"/>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Datum:%1
Iznos:%2
Tip:%3
Adresa:%4
</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="751"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Novčanik je &lt;b&gt;šifriran&lt;/b&gt; i trenutno &lt;b&gt;otključan&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="759"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Novčanik je &lt;b&gt;šifriran&lt;/b&gt; i trenutno &lt;b&gt;zaključan&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="782"/>
        <source>Backup Wallet</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="782"/>
        <source>Wallet Data (*.dat)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="785"/>
        <source>Backup Failed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="785"/>
        <source>There was an error trying to save the wallet data to the new location.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DisplayOptionsPage</name>
    <message>
        <location filename="../optionsdialog.cpp" line="270"/>
        <source>&amp;Unit to show amounts in: </source>
        <translation>&amp;Jedinica za prikazivanje iznosa:</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="274"/>
        <source>Choose the default subdivision unit to show in the interface, and when sending coins</source>
        <translation>Izaberite željeni najmanji dio SLIMCoina koji će biti prikazan u sučelju i koji će se koristiti za plaćanje.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="281"/>
        <source>Display addresses in transaction list</source>
        <translation>Prikaži adrese u popisu transakcija</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="14"/>
        <source>Edit Address</source>
        <translation>Izmjeni adresu</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="25"/>
        <source>&amp;Label</source>
        <translation>&amp;Oznaka</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="35"/>
        <source>The label associated with this address book entry</source>
        <translation>Oznaka ovog upisa u adresar</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="42"/>
        <source>&amp;Address</source>
        <translation>&amp;Adresa</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="52"/>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>Adresa ovog upisa u adresar. Može se mjenjati samo kod adresa za slanje.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="20"/>
        <source>New receiving address</source>
        <translation>Nova adresa za primanje</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="24"/>
        <source>New sending address</source>
        <translation>Nova adresa za slanje</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="27"/>
        <source>Edit receiving address</source>
        <translation>Uredi adresu za primanje</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="31"/>
        <source>Edit sending address</source>
        <translation>Uredi adresu za slanje</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="91"/>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>Upisana adresa &quot;%1&quot; je već u adresaru.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="96"/>
        <source>The entered address &quot;%1&quot; is not a valid SLIMCoin address.</source>
        <translation>Upisana adresa &quot;%1&quot; nije valjana SLIMCoin adresa.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="101"/>
        <source>Could not unlock wallet.</source>
        <translation>Ne mogu otključati novčanik.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="106"/>
        <source>New key generation failed.</source>
        <translation>Stvaranje novog ključa nije uspjelo.</translation>
    </message>
</context>
<context>
    <name>MainOptionsPage</name>
    <message>
        <location filename="../optionsdialog.cpp" line="170"/>
        <source>&amp;Start SLIMCoin on window system startup</source>
        <translation>&amp;Pokreni SLIMCoin kod pokretanja sustava</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="171"/>
        <source>Automatically start SLIMCoin after the computer is turned on</source>
        <translation>Automatski pokreni SLIMCoin kad se uključi računalo</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="175"/>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimiziraj u sistemsku traku umjesto u traku programa</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="176"/>
        <source>Show only a tray icon after minimizing the window</source>
        <translation>Prikaži samo ikonu u sistemskoj traci nakon minimiziranja prozora</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="180"/>
        <source>Map port using &amp;UPnP</source>
        <translation>Mapiraj port koristeći &amp;UPnP</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="181"/>
        <source>Automatically open the SLIMCoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Automatski otvori port SLIMCoin klijenta na ruteru. To radi samo ako ruter podržava UPnP i ako je omogućen.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="185"/>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimiziraj kod zatvaranja</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="186"/>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Minimizirati umjesto izaći iz aplikacije kada je prozor zatvoren. Kada je ova opcija omogućena, aplikacija će biti zatvorena tek nakon odabira Izlaz u izborniku.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="190"/>
        <source>&amp;Connect through SOCKS4 proxy:</source>
        <translation>&amp;Povezivanje putem SOCKS4 proxy-a:</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="191"/>
        <source>Connect to the Bitcon network through a SOCKS4 proxy (e.g. when connecting through Tor)</source>
        <translation>Spojite se na Bitcon mrežu putem SOCKS4 proxy-a (npr. kod povezivanja kroz Tor)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="196"/>
        <source>Proxy &amp;IP: </source>
        <translation>Proxy &amp;IP:</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="202"/>
        <source>IP address of the proxy (e.g. 127.0.0.1)</source>
        <translation>IP adresa proxy-a (npr. 127.0.0.1)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="205"/>
        <source>&amp;Port: </source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="211"/>
        <source>Port of the proxy (e.g. 1234)</source>
        <translation>Port od proxy-a (npr. 1234)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="217"/>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly.  Most transactions are 1 kB.  Fee 0.01 recommended.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="223"/>
        <source>Pay transaction &amp;fee</source>
        <translation>Plati &amp;naknadu za transakciju</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="226"/>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly. Most transactions are 1 kB. Fee 0.01 recommended.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MessagePage</name>
    <message>
        <location filename="../forms/messagepage.ui" line="14"/>
        <source>Message</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="20"/>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="38"/>
        <source>The address to send the payment to  (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Adresa za slanje plaćanja (npr. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="48"/>
        <source>Choose adress from address book</source>
        <translation>Odaberite adresu iz adresara</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="58"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="71"/>
        <source>Paste address from clipboard</source>
        <translation>Zalijepi adresu iz međuspremnika</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="81"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="93"/>
        <source>Enter the message you want to sign here</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="105"/>
        <source>Click &quot;Sign Message&quot; to get signature</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="117"/>
        <source>Sign a message to prove you own this address</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="120"/>
        <source>&amp;Sign Message</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="131"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopiraj trenutno odabranu adresu u međuspremnik</translation>
    </message>
    <message>
        <location filename="../forms/messagepage.ui" line="134"/>
        <source>&amp;Copy to Clipboard</source>
        <translation>&amp;Kopiraj u međuspremnik</translation>
    </message>
    <message>
        <location filename="../messagepage.cpp" line="74"/>
        <location filename="../messagepage.cpp" line="89"/>
        <location filename="../messagepage.cpp" line="101"/>
        <source>Error signing</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../messagepage.cpp" line="74"/>
        <source>%1 is not a valid address.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../messagepage.cpp" line="89"/>
        <source>Private key for %1 is not available.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../messagepage.cpp" line="101"/>
        <source>Sign failed</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../optionsdialog.cpp" line="79"/>
        <source>Main</source>
        <translation>Glavno</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="84"/>
        <source>Display</source>
        <translation>Prikaz</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="104"/>
        <source>Options</source>
        <translation>Postavke</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <location filename="../forms/overviewpage.ui" line="14"/>
        <source>Form</source>
        <translation>Oblik</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="40"/>
        <source>Balance:</source>
        <translation>Stanje:</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="47"/>
        <source>123.456 BTC</source>
        <translation>123,456 BTC</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="54"/>
        <source>Number of transactions:</source>
        <translation>Broj transakcija:</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="61"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="68"/>
        <source>Unconfirmed:</source>
        <translation>Nepotvrđene:</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="75"/>
        <source>0 BTC</source>
        <translation>0 BTC</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="82"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Wallet&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:11pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Lisnica&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="122"/>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Nedavne transakcije&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="103"/>
        <source>Your current balance</source>
        <translation>Vaše trenutno stanje računa</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="108"/>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Ukupni iznos transakcija koje tek trebaju biti potvrđene, i još uvijek nisu uračunate u trenutni saldo</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="111"/>
        <source>Total number of transactions in wallet</source>
        <translation>Ukupni broj tansakcija u lisnici</translation>
    </message>
</context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dijalog</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="32"/>
        <source>QR Code</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="52"/>
        <source>Request Payment</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="67"/>
        <source>Amount:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="102"/>
        <source>BTC</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="118"/>
        <source>Label:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="141"/>
        <source>Message:</source>
        <translation>Poruka:</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="183"/>
        <source>&amp;Save As...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="101"/>
        <source>Save Image...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="101"/>
        <source>PNG Images (*.png)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="14"/>
        <location filename="../sendcoinsdialog.cpp" line="122"/>
        <location filename="../sendcoinsdialog.cpp" line="127"/>
        <location filename="../sendcoinsdialog.cpp" line="132"/>
        <location filename="../sendcoinsdialog.cpp" line="137"/>
        <location filename="../sendcoinsdialog.cpp" line="143"/>
        <location filename="../sendcoinsdialog.cpp" line="148"/>
        <location filename="../sendcoinsdialog.cpp" line="153"/>
        <source>Send Coins</source>
        <translation>Pošalji novac</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="64"/>
        <source>Send to multiple recipients at once</source>
        <translation>Pošalji k nekoliko primatelja odjednom</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="67"/>
        <source>&amp;Add recipient...</source>
        <translation>&amp;Dodaj primatelja...</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="84"/>
        <source>Remove all transaction fields</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="87"/>
        <source>Clear all</source>
        <translation>Obriši sve</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="106"/>
        <source>Balance:</source>
        <translation>Stanje:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="113"/>
        <source>123.456 BTC</source>
        <translation>123,456 BTC</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="144"/>
        <source>Confirm the send action</source>
        <translation>Potvrdi akciju slanja</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="147"/>
        <source>&amp;Send</source>
        <translation>&amp;Pošalji</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="94"/>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; do %2 (%3)</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="99"/>
        <source>Confirm send coins</source>
        <translation>Potvrdi slanje novca</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="100"/>
        <source>Are you sure you want to send %1?</source>
        <translation>Jeste li sigurni da želite poslati %1?</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="100"/>
        <source> and </source>
        <translation>i</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="123"/>
        <source>The recepient address is not valid, please recheck.</source>
        <translation>Adresa primatelja je nevaljala, molimo provjerite je ponovo.</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="128"/>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Iznos mora biti veći od 0.</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="133"/>
        <source>Amount exceeds your balance</source>
        <translation>Iznos je veći od stanja računa</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="138"/>
        <source>Total exceeds your balance when the %1 transaction fee is included</source>
        <translation>Iznos je veći od stanja računa kad se doda naknada za transakcije od %1</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="144"/>
        <source>Duplicate address found, can only send to each address once in one send operation</source>
        <translation>Pronašli smo adresu koja se ponavlja. U svakom plaćanju program može svaku adresu koristiti samo jedanput</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="149"/>
        <source>Error: Transaction creation failed  </source>
        <translation>Greška: priprema transakcije nije uspjela</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="154"/>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Generirani novčići moraju pričekati nastanak 120 blokova prije nego što ih je moguće potrošiti. Kad ste generirali taj blok, on je bio emitiran u mrežu kako bi bio dodan postojećim lancima blokova. Ako ne uspije biti dodan, njegov status bit će promijenjen u &quot;nije prihvatljiv&quot; i on neće biti potrošiv. S vremena na vrijeme tako nešto se može desiti ako neki drugi nod približno istovremeno generira blok.</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="14"/>
        <source>Form</source>
        <translation>Oblik</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="29"/>
        <source>A&amp;mount:</source>
        <translation>&amp;Iznos:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="42"/>
        <source>Pay &amp;To:</source>
        <translation>&amp;Primatelj plaćanja:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="66"/>
        <location filename="../sendcoinsentry.cpp" line="26"/>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Unesite oznaku za ovu adresu kako bi ju dodali u vaš adresar</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="75"/>
        <source>&amp;Label:</source>
        <translation>&amp;Oznaka:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="93"/>
        <source>The address to send the payment to  (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Adresa za slanje plaćanja (npr. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="103"/>
        <source>Choose address from address book</source>
        <translation>Odaberite adresu iz adresara</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="113"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="120"/>
        <source>Paste address from clipboard</source>
        <translation>Zalijepi adresu iz međuspremnika</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="130"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="137"/>
        <source>Remove this recipient</source>
        <translation>Ukloni ovog primatelja</translation>
    </message>
    <message>
        <location filename="../sendcoinsentry.cpp" line="25"/>
        <source>Enter a SLIMCoin address (e.g. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</source>
        <translation>Unesite SLIMCoin adresu (npr. 1NS17iag9jJgTHD1VXjvLCEnZuQ3rJDE9L)</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <location filename="../transactiondesc.cpp" line="18"/>
        <source>Open for %1 blocks</source>
        <translation>Otvori za %1 blokova</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="20"/>
        <source>Open until %1</source>
        <translation>Otvoren do %1</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="26"/>
        <source>%1/offline?</source>
        <translation>%1 nije dostupan?</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="28"/>
        <source>%1/unconfirmed</source>
        <translation>%1/nepotvrđeno</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="30"/>
        <source>%1 confirmations</source>
        <translation>%1 potvrda</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="47"/>
        <source>&lt;b&gt;Status:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Status:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="52"/>
        <source>, has not been successfully broadcast yet</source>
        <translation>, još nije bio uspješno emitiran</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="54"/>
        <source>, broadcast through %1 node</source>
        <translation>, emitiran kroz nod %1 </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="56"/>
        <source>, broadcast through %1 nodes</source>
        <translation>, emitiran kroz nodove %1 </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="60"/>
        <source>&lt;b&gt;Date:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Datum:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="67"/>
        <source>&lt;b&gt;Source:&lt;/b&gt; Generated&lt;br&gt;</source>
        <translation>&lt;b&gt;Izvor:&lt;/b&gt; Generirano&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="73"/>
        <location filename="../transactiondesc.cpp" line="90"/>
        <source>&lt;b&gt;From:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Od:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="90"/>
        <source>unknown</source>
        <translation>nepoznato</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="91"/>
        <location filename="../transactiondesc.cpp" line="114"/>
        <location filename="../transactiondesc.cpp" line="173"/>
        <source>&lt;b&gt;To:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Za:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="94"/>
        <source> (yours, label: </source>
        <translation>(tvoje, oznaka:</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="96"/>
        <source> (yours)</source>
        <translation>(tvoje)</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="131"/>
        <location filename="../transactiondesc.cpp" line="145"/>
        <location filename="../transactiondesc.cpp" line="190"/>
        <location filename="../transactiondesc.cpp" line="207"/>
        <source>&lt;b&gt;Credit:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Uplaćeno:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="133"/>
        <source>(%1 matures in %2 more blocks)</source>
        <translation>(%1 stasava za %2 dodatna bloka)</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="137"/>
        <source>(not accepted)</source>
        <translation>(Nije prihvaćeno)</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="181"/>
        <location filename="../transactiondesc.cpp" line="189"/>
        <location filename="../transactiondesc.cpp" line="204"/>
        <source>&lt;b&gt;Debit:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Potrošeno:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="195"/>
        <source>&lt;b&gt;Transaction fee:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Naknada za transakciju:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="211"/>
        <source>&lt;b&gt;Net amount:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Neto iznos:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="217"/>
        <source>Message:</source>
        <translation>Poruka:</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="219"/>
        <source>Comment:</source>
        <translation>Komentar:</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="221"/>
        <source>Transaction ID:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="224"/>
        <source>Generated coins must wait 120 blocks before they can be spent.  When you generated this block, it was broadcast to the network to be added to the block chain.  If it fails to get into the chain, it will change to &quot;not accepted&quot; and not be spendable.  This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Generirani novčići moraju pričekati nastanak 120 blokova prije nego što ih je moguće potrošiti. Kad ste generirali taj blok, on je bio emitiran u mrežu kako bi bio dodan postojećim lancima blokova. Ako ne uspije biti dodan, njegov status bit će promijenjen u &quot;nije prihvaćen&quot; i on neće biti potrošiv. S vremena na vrijeme tako nešto se može desiti ako neki drugi nod generira blok u približno isto vrijeme.</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="14"/>
        <source>Transaction details</source>
        <translation>Detalji transakcije</translation>
    </message>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="20"/>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Ova panela prikazuje detaljni opis transakcije</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Type</source>
        <translation>Tip</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="213"/>
        <source>Amount</source>
        <translation>Iznos</translation>
    </message>
    <message numerus="yes">
        <location filename="../transactiontablemodel.cpp" line="274"/>
        <source>Open for %n block(s)</source>
        <translation><numerusform>Otvoren za %n bloka</numerusform><numerusform>Otvoren za %n blokova</numerusform><numerusform>Otvoren za %n blokova</numerusform></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="277"/>
        <source>Open until %1</source>
        <translation>Otvoren do %1</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="280"/>
        <source>Offline (%1 confirmations)</source>
        <translation>Nije na mreži (%1 potvrda)</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="283"/>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Nepotvrđen (%1 od %2 potvrda)</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="286"/>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Potvrđen (%1 potvrda)</translation>
    </message>
    <message numerus="yes">
        <location filename="../transactiontablemodel.cpp" line="295"/>
        <source>Mined balance will be available in %n more blocks</source>
        <translation><numerusform>Saldo iskovanih novčićća bit de dostupan nakon %n dodatnog bloka</numerusform><numerusform>Saldo iskovanih novčićća bit de dostupan nakon %n dodatnih blokova</numerusform><numerusform>Saldo iskovanih novčićća bit de dostupan nakon %n dodatnih blokova</numerusform></translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="301"/>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Generirano - Upozorenje: ovaj blok nije bio primljen od strane bilo kojeg drugog noda i vjerojatno neće biti prihvaćen!</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="304"/>
        <source>Generated but not accepted</source>
        <translation>Generirano, ali nije prihvaćeno</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="347"/>
        <source>Received with</source>
        <translation>Primljeno s</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="349"/>
        <source>Received from</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="352"/>
        <source>Sent to</source>
        <translation>Poslano za</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="354"/>
        <source>Payment to yourself</source>
        <translation>Plaćanje samom sebi</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="356"/>
        <source>Mined</source>
        <translation>Rudareno</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="394"/>
        <source>(n/a)</source>
        <translation>(n/d)</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="593"/>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Status transakcije</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="595"/>
        <source>Date and time that the transaction was received.</source>
        <translation>Datum i vrijeme kad je transakcija primljena</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="597"/>
        <source>Type of transaction.</source>
        <translation>Vrsta transakcije.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="599"/>
        <source>Destination address of transaction.</source>
        <translation>Odredište transakcije</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="601"/>
        <source>Amount removed from or added to balance.</source>
        <translation>Iznos odbijen od ili dodan k saldu.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <location filename="../transactionview.cpp" line="55"/>
        <location filename="../transactionview.cpp" line="71"/>
        <source>All</source>
        <translation>Sve</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="56"/>
        <source>Today</source>
        <translation>Danas</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="57"/>
        <source>This week</source>
        <translation>Ovaj tjedan</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="58"/>
        <source>This month</source>
        <translation>Ovaj mjesec</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="59"/>
        <source>Last month</source>
        <translation>Prošli mjesec</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="60"/>
        <source>This year</source>
        <translation>Ove godine</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="61"/>
        <source>Range...</source>
        <translation>Raspon...</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="72"/>
        <source>Received with</source>
        <translation>Primljeno s</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="74"/>
        <source>Sent to</source>
        <translation>Poslano za</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="76"/>
        <source>To yourself</source>
        <translation>Tebi</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="77"/>
        <source>Mined</source>
        <translation>Rudareno</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="78"/>
        <source>Other</source>
        <translation>Ostalo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="84"/>
        <source>Enter address or label to search</source>
        <translation>Unesite adresu ili oznaku za pretraživanje</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="90"/>
        <source>Min amount</source>
        <translation>Min iznos</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="124"/>
        <source>Copy address</source>
        <translation>Kopirati adresu</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="125"/>
        <source>Copy label</source>
        <translation>Kopirati oznaku</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="126"/>
        <source>Copy amount</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="127"/>
        <source>Edit label</source>
        <translation>Izmjeniti oznaku</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="128"/>
        <source>Show details...</source>
        <translation>Prikazati detalje...</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="268"/>
        <source>Export Transaction Data</source>
        <translation>Izvoz podataka transakcija</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="269"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Datoteka podataka odvojenih zarezima (*.csv)</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="277"/>
        <source>Confirmed</source>
        <translation>Potvrđeno</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="278"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="279"/>
        <source>Type</source>
        <translation>Tip</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="280"/>
        <source>Label</source>
        <translation>Oznaka</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="281"/>
        <source>Address</source>
        <translation>Adresa</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="282"/>
        <source>Amount</source>
        <translation>Iznos</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="283"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="287"/>
        <source>Error exporting</source>
        <translation>Izvoz pogreške</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="287"/>
        <source>Could not write to file %1.</source>
        <translation>Ne mogu pisati u datoteku %1.</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="382"/>
        <source>Range:</source>
        <translation>Raspon:</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="390"/>
        <source>to</source>
        <translation>za</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <location filename="../walletmodel.cpp" line="145"/>
        <source>Sending...</source>
        <translation>Slanje...</translation>
    </message>
</context>
<context>
    <name>SLIMCoin-core</name>
    <message>
        <location filename="../bitcoinstrings.cpp" line="3"/>
        <source>SLIMCoin version</source>
        <translation>SLIMCoin verzija</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="4"/>
        <source>Usage:</source>
        <translation>Upotreba:</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="5"/>
        <source>Send command to -server or slimcoind</source>
        <translation>Pošalji komandu usluzi -server ili slimcoind</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="6"/>
        <source>List commands</source>
        <translation>Prikaži komande</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="7"/>
        <source>Get help for a command</source>
        <translation>Potraži pomoć za komandu</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="8"/>
        <source>Options:</source>
        <translation>Postavke:</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="9"/>
        <source>Specify configuration file (default: SLIMCoin.conf)</source>
        <translation>Odredi konfiguracijsku datoteku (ugrađeni izbor: SLIMCoin.conf)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="10"/>
        <source>Specify pid file (default: slimcoind.pid)</source>
        <translation>Odredi proces ID datoteku (ugrađeni izbor: SLIMCoin.pid)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="11"/>
        <source>Generate coins</source>
        <translation>Generiraj novčiće</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="12"/>
        <source>Don&apos;t generate coins</source>
        <translation>Ne generiraj novčiće</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="13"/>
        <source>Start minimized</source>
        <translation>Pokreni minimiziran</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="14"/>
        <source>Specify data directory</source>
        <translation>Odredi direktorij za datoteke</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="15"/>
        <source>Specify connection timeout (in milliseconds)</source>
        <translation>Odredi vremenski prozor za spajanje na mrežu (u milisekundama)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="16"/>
        <source>Connect through socks4 proxy</source>
        <translation>Poveži se kroz socks4 proxy</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="17"/>
        <source>Allow DNS lookups for addnode and connect</source>
        <translation>Dozvoli DNS upite za dodavanje nodova i povezivanje</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="18"/>
        <source>Listen for connections on &lt;port&gt; (default: 8333 or testnet: 18333)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="19"/>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="20"/>
        <source>Add a node to connect to</source>
        <translation>Unesite nod s kojim se želite spojiti</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="21"/>
        <source>Connect only to the specified node</source>
        <translation>Poveži se samo sa određenim nodom</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="22"/>
        <source>Don&apos;t accept connections from outside</source>
        <translation>Ne prihvaćaj povezivanje izvana</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="23"/>
        <source>Don&apos;t bootstrap list of peers using DNS</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="24"/>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="25"/>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="28"/>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 10000)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="29"/>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 10000)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="30"/>
        <source>Don&apos;t attempt to use UPnP to map the listening port</source>
        <translation>Ne pokušaj koristiti UPnP da otvoriš port za uslugu</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="31"/>
        <source>Attempt to use UPnP to map the listening port</source>
        <translation>Pokušaj koristiti UPnP da otvoriš port za uslugu</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="32"/>
        <source>Fee per kB to add to transactions you send</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="33"/>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Prihvati komande iz tekst moda i JSON-RPC</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="34"/>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Izvršavaj u pozadini kao uslužnik i prihvaćaj komande</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="35"/>
        <source>Use the test network</source>
        <translation>Koristi test mrežu</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="36"/>
        <source>Output extra debugging information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="37"/>
        <source>Prepend debug output with timestamp</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="38"/>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="39"/>
        <source>Send trace/debug info to debugger</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="40"/>
        <source>Username for JSON-RPC connections</source>
        <translation>Korisničko ime za JSON-RPC veze</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="41"/>
        <source>Password for JSON-RPC connections</source>
        <translation>Lozinka za JSON-RPC veze</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="42"/>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 8332)</source>
        <translation>Prihvaćaj JSON-RPC povezivanje na portu broj &lt;port&gt; (ugrađeni izbor: 8332)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="43"/>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>Dozvoli JSON-RPC povezivanje s određene IP adrese</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="44"/>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Pošalji komande nodu na adresi &lt;ip&gt; (ugrađeni izbor: 127.0.0.1)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="45"/>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Podesi memorijski prostor za ključeve na &lt;n&gt; (ugrađeni izbor: 100)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="46"/>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Ponovno pretraži lanac blokova za transakcije koje nedostaju</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="47"/>
        <source>
SSL options: (see the SLIMCoin Wiki for SSL setup instructions)</source>
        <translation>SSL postavke: (za detalje o podešavanju SSL opcija vidi SLIMCoin Wiki)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="50"/>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Koristi OpenSSL (https) za JSON-RPC povezivanje</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="51"/>
        <source>Server certificate file (default: server.cert)</source>
        <translation>Uslužnikov SSL certifikat (ugrađeni izbor: server.cert)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="52"/>
        <source>Server private key (default: server.pem)</source>
        <translation>Uslužnikov privatni ključ (ugrađeni izbor: server.pem)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="53"/>
        <source>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</source>
        <translation>Prihvaljivi načini šifriranja (ugrađeni izbor: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="56"/>
        <source>This help message</source>
        <translation>Ova poruka za pomoć</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="57"/>
        <source>Cannot obtain a lock on data directory %s.  SLIMCoin is probably already running.</source>
        <translation>Program ne može pristupiti direktoriju s datotekama %s. SLIMCoin program je vjerojatno već pokrenut.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="60"/>
        <source>Loading addresses...</source>
        <translation>Učitavanje adresa...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="61"/>
        <source>Error loading addr.dat</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="63"/>
        <source>Error loading blkindex.dat</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="65"/>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="66"/>
        <source>Error loading wallet.dat: Wallet requires newer version of SLIMCoin</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="67"/>
        <source>Wallet needed to be rewritten: restart SLIMCoin to complete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="68"/>
        <source>Error loading wallet.dat</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="62"/>
        <source>Loading block index...</source>
        <translation>Učitavanje indeksa blokova...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="64"/>
        <source>Loading wallet...</source>
        <translation>Učitavanje novčanika...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="69"/>
        <source>Rescanning...</source>
        <translation>Rescaniranje</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="70"/>
        <source>Done loading</source>
        <translation>Učitavanje gotovo</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="71"/>
        <source>Invalid -proxy address</source>
        <translation>Nevaljala -proxy adresa</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="72"/>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;</source>
        <translation>Nevaljali iznos za opciju -paytxfee=&lt;amount&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="73"/>
        <source>Warning: -paytxfee is set very high.  This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Upozorenje: -paytxfee je podešen na preveliki iznos.  To je iznos koji ćete platiti za obradu transakcije.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="76"/>
        <source>Error: CreateThread(StartNode) failed</source>
        <translation>Greška: CreateThread(StartNode) nije uspjela</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="77"/>
        <source>Warning: Disk space is low  </source>
        <translation>Upozorenje: Malo diskovnog prostora</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="78"/>
        <source>Unable to bind to port %d on this computer.  SLIMCoin is probably already running.</source>
        <translation>Program ne može koristiti port %d na ovom računalu.  SLIMCoin program je vjerojatno već pokrenut.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="81"/>
        <source>Warning: Please check that your computer&apos;s date and time are correct.  If your clock is wrong SLIMCoin will not work properly.</source>
        <translation>Upozorenje: Molimo provjerite jesu li datum i vrijeme na vašem računalu točni. Ako vaš sat ide krivo, SLIMCoin neće raditi ispravno.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="84"/>
        <source>beta</source>
        <translation>beta</translation>
    </message>
</context>
</TS>